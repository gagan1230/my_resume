var bio = {
  "name": "Gagandeep kaur",
  "role": "Software Developer",
  "contacts": {
    "mobile":"8427436684",
    "email": "gagank006@gmail.com",
    "github": "gagank",
    "twitter":"gagank006",
    "location": "patiala, chandigarh"
  },
  
  "biopic":"images/a.png",
  "welcomeMessage": "I am Gagan,I am currently persuing BTECH from Chitkara University and I am sincere towards my work very much.",
  "skills": ["SQL", "C++", "python","english"],

};

var education = {
  "schools": [
    { "name": "Gian Jyoti public school",
      "location":"mohali",
      "degree": "Matrix",
      "majors":["math","GK","Science"],
      "url":"www.google.com",
      "dates":"17-4-2017"
    }   
  ],
  "onlineCourses": [
    { "title": "c++",
      "school": "hackerrank",
      
      "dates": "November 2011",
      "url": "https://www.hackerrank.com",

    }
  ]
};
var work = {
  "jobs": [
    {
      "employer": "Superidentend",
      "title":"Software Manager",
      "location": "zrk",
      "dates": "January 2017",
      "description": "It was a good experience"
    },
    {
      "employer": "Manager",
      "title": "Managing districts",
      "location": "Amritsar,ludhiana,Hoshiyar",
      "dates": "March 2016 - December 2016",
      "description":"It was a good experience"
    },
    {
      "employer": "Supporter",
      "title": "Helper",
      "location": "zirakpur,Mohali,chandigarh",
      "dates": "Sept 2007",
      "description": "It was a good experience"
    }
    
  ]
};
var projects = {
  "projects": [
    {
      "title": "Hashing",
      "dates": "Dec 2016",
      "description": "Created an Hashing program in c++ ",
      "images": ["images/c.png"],
    }
    
  ]
};



bio.display=function() {
      var name = HTMLheaderName.replace("%data%", bio.name);
      var Role = HTMLheaderRole.replace("%data%", bio.role);
      var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);

   var formattedMsg =HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
   $("#header").append(formattedMsg);

   var Pic =HTMLbioPic.replace("%data%", bio.biopic);
   var a = [];
a.push(HTMLemail.replace("%data%", bio.contacts.email));
a.push(HTMLgithub.replace("%data%", bio.contacts.github));
a.push(HTMLtwitter.replace("%data%", bio.contacts.twitter));
a.push(HTMLlocation.replace("%data%", bio.contacts.location));

for(var i in a) {
  $("#topContacts").append(a[i]);
  $("#footerContacts").append(a[i]);
}
   $("#header").append(Pic);
   
   $("#header").prepend(Role);
   $("#header").prepend(name);
   $("#topContacts").prepend(formattedMobile);
   $('#footerContacts').prepend(formattedMobile);
   $("#header").append(HTMLskillsStart);
   
 
    bio.skills.forEach(function(skill){
    
   var a=HTMLskills.replace("%data%",skill);
   $("#skills").append(a);
});
   
};
bio.display();


projects.display = function() {
    projects.projects.forEach(function(p) {


      $("#projects").append(HTMLprojectStart);

      var formattedProjectTitle = HTMLprojectTitle.replace("%data%", p.title).replace("#", p.url);
      var formattedProjectDates = HTMLprojectDates.replace("%data%", p.dates);
      var formattedProjectDescription = HTMLprojectDescription.replace("%data%", p.description);

      $(".project-entry:last").append(formattedProjectTitle);
      $(".project-entry:last").append(formattedProjectDates);
      $(".project-entry:last").append(formattedProjectDescription);
      p.images.forEach(function(image){
    // format and display 'image'

        var formattedProjectImage = HTMLprojectImage.replace("%data%", image);
        $(".project-entry:last").append(formattedProjectImage); 
      });
      
    });
      
};

projects.display();

work.display=function() {  
    $("#workExperience").append(HTMLworkStart);
      work.jobs.forEach(function(works) {

      var formattedEmployer = HTMLworkEmployer.replace("%data%", works.employer);
      var formattedWorkTitle = HTMLworkTitle.replace("%data%", works.title);
      var formattedWorkLocation = HTMLworkLocation.replace("%data%", works.location);
      var formattedDatesWorked = HTMLworkDates.replace("%data%", works.dates);
      var formattedWorkDescription = HTMLworkDescription.replace("%data%", works.description);

      var formattedEmployerWorkTitle = formattedEmployer + formattedWorkTitle;

      $(".work-entry:last").append(formattedEmployerWorkTitle);
      $(".work-entry:last").append(formattedWorkLocation);
      $(".work-entry:last").append(formattedDatesWorked);
      $(".work-entry:last").append(formattedWorkDescription);
      });

};

work.display();


education.display = function () {

  education.onlineCourses.forEach(function(newCourses) {  
 $("#education").append(HTMLonlineClasses); 
     $("#education").append(HTMLschoolStart);
     var formattedonTitle = HTMLonlineTitle.replace("%data%",newCourses.title).replace("#", newCourses.url);
     var formattedSchool = HTMLonlineSchool.replace("%data%", newCourses.school);
     var formattedDates = HTMLonlineDates.replace("%data%", newCourses.dates);
      var formattedURL = HTMLonlineURL.replace("%data%", newCourses.url).replace("#", newCourses.url);
      $(".education-entry:last").append(formattedonTitle + formattedSchool);
      $(".education-entry:last").append(formattedDates);
      $(".education-entry:last").append(formattedURL);      
   

});

education.schools.forEach(function(newschools) {
 $("#education").append(HTMLschoolStart);

  var formattedSchools = HTMLschoolName.replace("%data%", newschools.name);
  var formattedDegree = HTMLschoolDegree.replace("%data%", newschools.degree);
  var formattedTitle = formattedSchools + formattedDegree;
  var c=HTMLschoolDates.replace("%data%",newschools.dates);

  $(".education-entry:last").append(formattedTitle);
  $(".education-entry:last").append(c);

  var formattedLocation = HTMLschoolLocation.replace ("%data%", newschools.location);
  $(".education-entry:last").append(formattedLocation);

  var formattedMajor = HTMLschoolMajor.replace("%data%", newschools.majors);
  $(".education-entry:last").append(formattedMajor);
 
  
  }); 
 

    
};
$("#mapDiv").append(googleMap);
education.display();

